//View.cpp    || Discipulos de Eli Banks(DEB)
//Nome dos integrantes do grupo:
//Pedro Marques Prado				Giovana Akemi Maeda Mathias
//Lucas Kenji Hayashi				Ricardo Lins Pires
#include <stdio.h>
#include "Dom_DEB_View.h"

//funcao participante da logica do menu
int menuGeral() {

	printf("=================================");
	printf("\n\n   ----- Jogo de Domino -----   \n\n");
	printf("=================================\n\n");
	printf("[1] Iniciar jogo (2 jogadores)\n");
	printf("[2] Iniciar jogo (contra computador)\n");
	printf("[3] Retomar ao jogo interrompido\n");
	printf("[4] Regras gerais do jogo\n");
	printf("[5] Salvar o jogo\n");
	printf("[6] Recuperar o jogo salvo\n");
	printf("[0] Sair\n\n");
	printf("Digite uma das opcoes acima: ");
	scanf("%d",&OP);
	if((OP < 0) || (OP > 6)) 
		printf("Erro: escolha uma opcao valida\n");
	
	return OP;
}

//funcao que apresenta as pecas de domino,em sua condicao atual
void apresentaPecas() {
	int numero, px;
	
	if(Vez % 2 == 1) 
		{
			// ---------- MOSTRA TODAS AS PECAS DO JOGADOR ----------
		printf("Pecas do jogador 1:\n");
		numero = 0;
		for(px = 0; px < 28; px++) 
			{
			if(pecas[px].status == '1') 
				{
				numero++;
				printf("%d.[%d|%d]   ", numero, pecas[px].Lado1, pecas[px].Lado2);
				}
			}
	printf("\n");
		}
		
	if(Vez % 2 == 0) 
		{
			// ---------- MOSTRA TODAS AS PECAS DO JOGADOR ----------
		printf("Pecas do jogador 2:\n");
		numero = 0;
		for(px = 0; px < 28; px++) 
			{
			if(pecas[px].status == '2') 
				{
				numero++;
				printf("%d.[%d|%d]   ", numero, pecas[px].Lado1, pecas[px].Lado2);
				}
			}	
		}
}

void apresentaMesa()
{
	
	printf("\t\t||||||TURNO %d||||||",Turno);
	printf("\n===================================================\n\n");
		printf("MESA :");
		
		for(int i = 0; i < PosicaoNaMesa; i++)	
			{
				printf("[%d|%d]",Mesa[i].Lado1,Mesa[i].Lado2);	
			}
			
		printf("\n\n---------------------------------------------------\n");
}

void SubMenu()
{
		// --------------- MENU DE OPCOES ---------------
				printf("\n===================================================\n");
				printf("\nJ - Jogar\n");
				printf("C - Comprar\n");
				printf("P - Passar\n");
				printf("S - Sair\n");
				printf("Opcao: ");
				scanf("%s",&Jogador);
				
}

void regrasgerais()
{
    printf("\t\t |||||REGRAS GERAIS|||||\n");
	printf("1. A partida e iniciada pelo jogador que possuir a peca seis-seis. Caso nao haja, e iniciado por quem possuir a peca com numeros repetidos mais altos.\n\n");
    printf("2. Jogadores,em seu turno, so podem posicionar pecas as quais tenham os mesmos numeros de alguma das pecas das extremidades.\n\n");
    printf("3. Se um jogador nao tiver uma peca que nao coincida com nenhuma das pecas localizadas nas extremidades, ele devera pegar pecas extra ate que seja possivel fazer alguma jogada.\n\n");
    printf("4. Quando jogado por dois jogadores, o jogador que conseguir jogar sua ultima peca vence  e assim o jogo e finalizado.\n\n ");
}


int mensagens(int mensagem)
{
	
	switch(mensagem)
	{
		case 1:
			printf("\nNumero da peca a ser jogada(0 para voltar): ");
		break;
		case 2:
			printf("Lugar a ser jogada a peca (E=esquerda D=direita): ");
		break;
		case 3:
			printf("Erro, escolha uma peca valida.\n");
		break;
		case 4:
			printf("Comprou 1 peca\n");
		break;
		case 5:
			printf("\n\nEscolha uma das opcoes acima.\n\n\n");
		break;
		case 6:
			printf("\n\n\n ERROR. Jogador 2 nao e player nem bot \n\n\n");
		break;
		case 7:
			printf("\n\n\nJOGO FINALIZADO!\n\n\n");
		break;
		case 8:
			printf("\n\n\n\n\nEMPATE: Tanto o numero de pecas quanto a soma dos numeros dos 2 jogadores sao iguais");
		break;
		case 9:
			printf("\n\n\n\n\nFim de Jogo! O Jogador %d venceu!");
		case 10:
			printf("Salvando jogo...\n");
		break;
		case 11:
			printf("o arquivo PecasJogadores nao pode ser aberto para gravacao\n");
		break;
		case 12: 
			printf("Erro na gravacao do arquivo PecasJogadores");
		break;
		case 13:
			printf("O arquivo PosicaoNaMesa nao pode ser aberto para gravacao\n");
		break;
		case 14:
			printf("Erro na gravacao do arquivo PosicaoNaMesa");
		break;
		case 15: 
			printf("o arquivo Mesa nao pode ser aberto para gravacao\n");
		break;
		case 16:
			printf("Erro na gravacao do arquivo Mesa");
		break;
		case 17:
			printf("O arquivo VezJogador nao pode ser aberto para gravacao\n");
		break;
		case 18:
			printf("Erro na gravacao do arquivo VezSalvo");
		break;
		case 19:
			printf("SALVO!\n");
		break;
		case 20:
			printf("o arquivo PecasJogadores nao pode ser aberto para leitura\n");
		break;
		case 21:
			printf("Erro na leitura do arquivo PecasJogadores");
		break;
		case 22:
			printf("O arquivo PosicaoNaMesa nao pode ser aberto para leitura\n");
		break;
		case 23:
			printf("Erro na leitura do arquivo PosicaoNaMesa");
		break;
		case 24:
			printf("o arquivo Mesa nao pode ser aberto para leitura\n");
		break;
		case 25:
			printf("Erro na leitura do arquivo Mesa");
		break;
		case 26:
			printf("O arquivo VezJogador nao pode ser aberto para leitura\n");
		break;
		case 27:
			printf("Erro na leitura do arquivo VezSalvo");
		break;
		case 28:
			printf("RECUPERADO\n");
		break;
		case 29:
			printf("\n\n\n\n\n(O jogador %d fez a primeira jogada)", Vez);
		break;
		case 30:
			printf("Erro: Escolha uma opcao valida no menu\n");
		break;
		case 31:
			printf("Posicao na mesa: %d\n",PosicaoNaMesa);
		break;
		case 32:
			printf("\nErro: Escolha um lado valido.\n");
		break;
			
	}
	
	return mensagem;
	
}
