//Controller.h    || Discipulos de Eli Banks(DEB)
//Nome dos integrantes do grupo:
//Pedro Marques Prado				Giovana Akemi Maeda Mathias
//Lucas Kenji Hayashi				Ricardo Lins Pires

void geraPecas();
void embaralhaPecas();
void executarMenu();
void iniciarJogo();
void jogarBot();
void jogar();
void FimDeJogo();
void SalvarJogo();
void RecuperaJogo();
void fclear();
