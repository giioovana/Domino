//Projeto.cpp    || Discipulos de Eli Banks(DEB)
//Nome dos integrantes do grupo:
//Pedro Marques Prado				Giovana Akemi Maeda Mathias
//Lucas Kenji Hayashi				Ricardo Lins Pires
#include <stdio.h>
#include "Dom_DEB_Model.cpp"
#include "Dom_DEB_Controller.cpp"

main()
{
	geraPecas();
	embaralhaPecas();
	executarMenu();
}
