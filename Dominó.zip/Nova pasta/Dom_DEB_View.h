//View.h    || Discipulos de Eli Banks(DEB)
//Nome dos integrantes do grupo:
//Pedro Marques Prado				Giovana Akemi Maeda Mathias
//Lucas Kenji Hayashi				Ricardo Lins Pires

int menuGeral();
int Vez;
void apresentaPecas();
void BotJogandoV();
void apresentaMesa();
void SubMenu();
void regrasgerais();
void mensagens();
