//Model.cpp    || Discipulos de Eli Banks(DEB)
//Nome dos integrantes do grupo:
//Pedro Marques Prado				Giovana Akemi Maeda Mathias
//Lucas Kenji Hayashi				Ricardo Lins Pires

struct pc //struct que guarda as informacoes das pecas, e cria o vetor com as 28 pecas
{
	int Lado1;
	int Lado2;
	char status;
}; 
struct pc Mesa[28]; //struct do mesmo tipo pc para apresentar as pecas na mesa
struct pc pecas[28];
int MF;
int OP;
int BotJogando;
char Jogador;
int qtdMesa;
char LadoEscolhido;
int PosicaoNaMesa;
int VezSalvo;
int Turno;
int Bot;


