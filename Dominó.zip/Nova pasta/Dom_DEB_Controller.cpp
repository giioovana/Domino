//Controller.cpp    || Discipulos de Eli Banks(DEB)
//Nome dos integrantes do grupo:
//Pedro Marques Prado				Giovana Akemi Maeda Mathias
//Lucas Kenji Hayashi				Ricardo Lins Pires
#include <stdlib.h>
#include <time.h>
#include "Dom_DEB_Controller.h"
#include "Dom_DEB_View.cpp"

//essa funcao gera as pecas utilizada no jogo de domino
void geraPecas() {
	int px, i, j;
	for (int i = 0; i <= 6; i++) {
		for (int j = i; j <= 6; j++) {
			pecas[px].Lado1 = i;
			pecas[px].Lado2 = j;
			px++;
		}
	}
}

//essa funcao e responsavel por embaralhar as pecas previamente geradas
void embaralhaPecas() {
	int px, x;              //px = variavel auxiliar na manipulacao do vetor
	struct pc aux;          //struct pc aux & x = variavel do tipo pc e outra normal para realizar a troca das pecas.
	srand(time(0));

	for (px = 0; px < 28; px++) {
		x = rand() % 28;
		aux = pecas[px];
		pecas[px] = pecas[x];
		pecas[x] = aux;
	}
}

//essa funcao representa a logica do menu
void executarMenu() {



	do {
		OP = menuGeral();
		system("cls");
		switch (OP) {

			case 1: {
				iniciarJogo();
				jogar();
				break;
			}
			case 2: {
				iniciarJogo();
				BotJogandoV();
				jogar();
				break;
			}
			case 3: {
				jogar();
				break;
			}
			case 4: {
				regrasgerais();
				system("pause");
				break;
			}
			case 5:
				SalvarJogo();
				mensagens(19);
				break;

			case 6: {
				RecuperaJogo();
				mensagens(28);
				break;
			}
			case 0:
				break;
			default:
				mensagens(30);
				OP = -1;
		}
	} while (OP != 0);
}

void iniciarJogo() {
	int px;
	int numero = 0;  // variavel para apresentar em ordem os dominos, visivel ao usuario
	int LadoMaior = -1;
	int LadoMenor = -1;
	int LadoMaiorJ;                    //as variaveis "Lado" sao para armazenar informacoes dos maiores lados das pecas, para pegar a peca maior do j1 ou j2
	int LadoMenorJ;
	int NumeroMaiorSoma;
	char StatusMaiorSoma;

	for (px = 0; px < 28; px++) {
		pecas[px].status = 'C';
		numero++;
	}
	numero = 0;
	// -------------- ALOCA AS PECAS 0,1,2,3,4,5,6 DO JOGO AO JOGADOR 1 --------------
	for (px = 0; px < 7; px++) {
		pecas[px].status = '1';
		numero++;
	}
	numero = 0;

	// -------------- ALOCA AS PECAS 7,8,9,10,11,12,13 DO JOGO AO JOGADOR 2 --------------
	for (px = 7; px < 14; px++) {
		pecas[px].status = '2';
		numero++;
	}

	for (px = 0; px < 14; px++) {
		if (pecas[px].Lado1 == pecas[px].Lado2) {							//verifica se os 2 lados das pecas sao iguais 14x
			LadoMenor = pecas[px].Lado1;										//verifica a peca de maior soma
			if (LadoMenor > LadoMaior) {
				LadoMaior = LadoMenor;
				NumeroMaiorSoma = px;
				StatusMaiorSoma = pecas[px].status;
			}
		}
	}
	MF = NumeroMaiorSoma;

	// -------------- IDENTIFICA QUAL A MAIOR PECA DO JOGO, E QUEM VAI COMECAR --------------
	if (LadoMaior == -1 && LadoMenor == -1) {
		int MarcadorJ1 = -1;
		int MarcadorJ2 = -1;

		LadoMaiorJ = pecas[0].Lado1 + pecas[0].Lado2;
		for (px = 0; px < 7; px++) {
			LadoMenorJ = pecas[px].Lado1 + pecas[px].Lado2;
			if (LadoMaiorJ < LadoMenorJ) {
				LadoMaiorJ = LadoMenorJ;
				MarcadorJ1 = px;
			}
		}
		LadoMaiorJ = pecas[0].Lado1 + pecas[0].Lado2;
		for (px = 7; px < 14; px++) {
			LadoMenorJ = pecas[px].Lado1 + pecas[px].Lado2;                //parametro responsavel por reconhecer caso a soma da maior peca do j1 for igual a soma
			if (LadoMaiorJ < LadoMenorJ) {								   //da maior do j2, que em seu caso escolhe a primeira peca a ser jogada pelo lado maior.
				LadoMaiorJ = LadoMenorJ;
				MarcadorJ2 = px;
			}
		}
		if (pecas[MarcadorJ1].Lado1 + pecas[MarcadorJ1].Lado2 == pecas[MarcadorJ2].Lado1 + pecas[MarcadorJ2].Lado2) {
			int M = pecas[MarcadorJ1].Lado1, N = -1;

			if (M < pecas[MarcadorJ1].Lado2) {
				M = pecas[MarcadorJ1].Lado2;
				N = MarcadorJ1;
			} else if (M < pecas[MarcadorJ2].Lado1) {
				M = pecas[MarcadorJ2].Lado1;
				N = MarcadorJ2;
			} else if (M < pecas[MarcadorJ2].Lado2) {
				M = pecas[MarcadorJ2].Lado2;
				N = MarcadorJ2;
			}
		}
		if (MarcadorJ1 < 7)
			MF = MarcadorJ1;
		if (MarcadorJ2 > 6)
			MF = MarcadorJ2;
	}

	//Mesa[MF] = pecas[MF];
	pecas[MF].status = 'M';                                       //identificacao de que jogador comeca,depois apresenta na mesa a primeira peca jogada autom.
	for (int PosicaoNaMesaFOR = 0; PosicaoNaMesaFOR < 28; PosicaoNaMesaFOR++)
		Mesa[PosicaoNaMesaFOR].Lado1 = -1;
	Mesa[0].Lado1 = pecas[MF].Lado1;
	Mesa[0].Lado2 = pecas[MF].Lado2;
	if (MF < 7)
		Vez = 1;
	else
		Vez = 2;
	mensagens(29);    
	Vez++;
	PosicaoNaMesa = 1;
	Turno = 1;
}

void BotJogandoV() {
	BotJogando=1;
}

void jogar() {

	int px, numero, opcaoPecas, OK;
	int PosicaoMaoJ;
	int PecaEscolhidaERROR; //erro para reinciiar o submenu caso peca jogada seja invalida
	int essapeca;			//variavel que auxilia na busca da peca a ser jogada,escolhida pelo jogador
	int contadorpecas = 0;  //outra variavel que auxilia na contagem das pecas do jogador,que trabalha juntamente com a anterior
	int mostraMesa;			//contador que auxilia na apresentacao da mesa quando reinciiar o submenu//contador para apresentar os turnos
	int Voltarpromenu;

	if ((VezSalvo != 0) && (VezSalvo % 2 != 0)) {
		Vez = VezSalvo;
		Turno = VezSalvo;
		VezSalvo = 0;
	}

	else if ((VezSalvo != 0) && (VezSalvo % 2 == 0)) {
		Vez = VezSalvo;
		Turno = VezSalvo - 1;
		VezSalvo = 0;
	}

	do {
		OK = 0;
		PosicaoMaoJ = 1;
		PecaEscolhidaERROR = 0;
		contadorpecas = 0;
		mostraMesa = 1;
		system("cls");
		
		int RepetirJogarPeca;
		int RepetirEscolherLado;
		int numeroX;


		// ---------- MOSTRA A MESA ----------
		apresentaMesa();


		// ---------- FUNCAO DO JOGADOR 1 ----------
		if (Vez % 2 != 0) {
			Voltarpromenu = 0;
			do {
				if (mostraMesa > 1) {
					system("cls");
					apresentaMesa();
				}
				apresentaPecas();

				SubMenu();

				switch (Jogador) {
					case 'J':
					case 'j': {
			
							do { //while RepetirJogarPeca = 1
							RepetirJogarPeca = 0;
							
							// Pergunta qual peca quer jogar
							mensagens(1);
							scanf("%d", &opcaoPecas);
							if (opcaoPecas == 0) {
								OK = 0;
								break;
							}
							mensagens(31);
							
							// Numera todas as pecas do jogador
							contadorpecas=0;
							for (px = 0; px < 28; px++) {
								if (pecas[px].status == '1') {
									contadorpecas = contadorpecas + 1;
									if (contadorpecas == opcaoPecas) {
										essapeca = px;
									}
								}
							}
							
							//printf("\npeca q eu escolhi: [%d|%d]\n",pecas[essapeca].Lado1,pecas[essapeca].Lado2);
							
							
							// Verifica se eh valida na ESQ e na DIR ao msm tempo
							if (((pecas[essapeca].Lado1 == Mesa[PosicaoNaMesa - 1].Lado2) || (pecas[essapeca].Lado2 == Mesa[PosicaoNaMesa - 1].Lado2)) && ((pecas[essapeca].Lado2 == Mesa[0].Lado1) || (pecas[essapeca].Lado1 == Mesa[0].Lado1))){
								
								do{ //while RepetirEscolherLado = 1
									
									RepetirEscolherLado = 0;
									
									// Pergunta qual lado escolhido
									mensagens(2);
									scanf("%s",&LadoEscolhido);
									
							
									// Caso DIR escolhido
									if (LadoEscolhido == 'D'){
										
										//Caso DIR NORMAL
										if (pecas[essapeca].Lado1 == Mesa[PosicaoNaMesa - 1].Lado2){
											Mesa[PosicaoNaMesa].Lado1 = pecas[essapeca].Lado1;
											Mesa[PosicaoNaMesa].Lado2 = pecas[essapeca].Lado2;
											pecas[essapeca].status = 'M';
											PosicaoNaMesa++;
											OK = 1;
										}
										
										//caso DIR INV
										else if (pecas[essapeca].Lado2 == Mesa[PosicaoNaMesa - 1].Lado2){
											Mesa[PosicaoNaMesa].Lado1 = pecas[essapeca].Lado2;
											Mesa[PosicaoNaMesa].Lado2 = pecas[essapeca].Lado1;
											pecas[essapeca].status = 'M';
											PosicaoNaMesa++;
											OK = 1;
										}	
									}
									
									// Caso ESQ escolhido
									else if (LadoEscolhido == 'E'){
										
										// Passa tds as pecas da mesa 1 posicao pra direita
										for (int j = PosicaoNaMesa; j >= 0; j--) {
											Mesa[j + 1] = Mesa[j];
										}
										
										//Caso ESQ NORMAL
										if (pecas[essapeca].Lado2 == Mesa[0].Lado1){
											Mesa[0].Lado1 = pecas[essapeca].Lado1;
											Mesa[0].Lado2 = pecas[essapeca].Lado2;
											pecas[essapeca].status = 'M';
											PosicaoNaMesa++;
											OK = 1;
										}
										
										//Caso ESQ INV
										else if (pecas[essapeca].Lado1 == Mesa[0].Lado1){
											Mesa[0].Lado1 = pecas[essapeca].Lado2;
											Mesa[0].Lado2 = pecas[essapeca].Lado1;
											pecas[essapeca].status = 'M';
											PosicaoNaMesa++;
											OK = 1;
										}
									} 
									
									// Caso nem DIR nem ESQ
									else{
										RepetirEscolherLado=1;
										mensagens(32);
									}
									
								}while (RepetirEscolherLado == 1);
							}
							
							// Verifica se eh valida na DIR
							else if ((pecas[essapeca].Lado1 == Mesa[PosicaoNaMesa - 1].Lado2) || (pecas[essapeca].Lado2 == Mesa[PosicaoNaMesa - 1].Lado2)){
								
								//Caso DIR NORMAL
								if (pecas[essapeca].Lado1 == Mesa[PosicaoNaMesa - 1].Lado2){
									Mesa[PosicaoNaMesa].Lado1 = pecas[essapeca].Lado1;
									Mesa[PosicaoNaMesa].Lado2 = pecas[essapeca].Lado2;
									pecas[essapeca].status = 'M';
									PosicaoNaMesa++;
									OK = 1;
								}
								
								//caso DIR INV
								else if (pecas[essapeca].Lado2 == Mesa[PosicaoNaMesa - 1].Lado2){
									Mesa[PosicaoNaMesa].Lado1 = pecas[essapeca].Lado2;
									Mesa[PosicaoNaMesa].Lado2 = pecas[essapeca].Lado1;
									pecas[essapeca].status = 'M';
									PosicaoNaMesa++;
									OK = 1;
								}
										
							}
							
							// Verifica se eh valida na ESQ
							else if ((pecas[essapeca].Lado1 == Mesa[0].Lado1) || (pecas[essapeca].Lado2 == Mesa[0].Lado1)){
										
								// Passa tds as pecas da mesa 1 pra direita
								for (int j = PosicaoNaMesa; j >= 0; j--) {
									Mesa[j + 1] = Mesa[j];
								}
										
								//Caso ESQ NORMAL
								if (pecas[essapeca].Lado2 == Mesa[0].Lado1){
									Mesa[0].Lado1 = pecas[essapeca].Lado1;
									Mesa[0].Lado2 = pecas[essapeca].Lado2;
									pecas[essapeca].status = 'M';
									PosicaoNaMesa++;
									OK = 1;
								}
										
								//Caso ESQ INV
								else if (pecas[essapeca].Lado1 == Mesa[0].Lado1){
									Mesa[0].Lado1 = pecas[essapeca].Lado2;
									Mesa[0].Lado2 = pecas[essapeca].Lado1;
									pecas[essapeca].status = 'M';
									PosicaoNaMesa++;
									OK = 1;
								}				
							}
							
							// Caso nenhum dos 3 acima
							else{
								RepetirJogarPeca = 1;
								mensagens(3);
								//printf("posicao na mesa: %d\n",PosicaoNaMesa);
								//printf("\npeca q eu escolhi: [%d|%d]\n",pecas[numeroX].Lado1,pecas[numeroX].Lado2);
							}
							
						} while(RepetirJogarPeca == 1);

							break;
						}
					case 'C':
					case 'c': {
						for (px = 0; px < 28; px++) {
							if (pecas[px].status == 'C') {
								pecas[px].status = '1';
								px = 28;

							}
						}
						mensagens(4);
						OK = 0;
						break;
					}
					case 'P':
					case 'p':
						OK = 1;
						break;
					case 'S':
					case 's': {
						OK = 1;
						Voltarpromenu = 1;
						break;
					}

					default: {
						mensagens(5);
						OK = 0;
						break;
					}

				}
				mostraMesa = mostraMesa + 1;
			} while (OK == 0);

		}

		OK = 1;
		
		// ---------- FUNCAO DO JOGAODOR 2 ----------
		if (Vez % 2 == 0) {
			Voltarpromenu = 0;

			// CASO SEJA UM JOGADOR
			if (BotJogando == 0) {

				do {

					if (mostraMesa > 1) {
						system("cls");
						apresentaMesa();
					}
					apresentaPecas();
					// --------------- MENU DE OPCOES ---------------
					SubMenu();

					switch (Jogador) {
						case 'J':
						case 'j': {
			
							do { //while RepetirJogarPeca = 1
							RepetirJogarPeca = 0;
							
							// Pergunta qual peca quer jogar
							mensagens(1);
							scanf("%d", &opcaoPecas);
							if (opcaoPecas == 0) {
								OK = 0;
								break;
							}
							mensagens(31);
							
							// Numera todas as pecas do jogador
							contadorpecas=0;
							for (px = 0; px < 28; px++) {
								if (pecas[px].status == '2') {
									contadorpecas = contadorpecas + 1;
									if (contadorpecas == opcaoPecas) {
										essapeca = px;
									}
								}
							}
							
							//printf("\npeca q eu escolhi: [%d|%d]\n",pecas[essapeca].Lado1,pecas[essapeca].Lado2);
							
							
							// Verifica se eh valida na ESQ e na DIR ao msm tempo
							if (((pecas[essapeca].Lado1 == Mesa[PosicaoNaMesa - 1].Lado2) || (pecas[essapeca].Lado2 == Mesa[PosicaoNaMesa - 1].Lado2)) && ((pecas[essapeca].Lado2 == Mesa[0].Lado1) || (pecas[essapeca].Lado1 == Mesa[0].Lado1))){
								
								do{ //while RepetirEscolherLado = 1
									
									RepetirEscolherLado = 0;
									
									// Pergunta qual lado escolhido
									mensagens(2);
									scanf("%s",&LadoEscolhido);
									
							
									// Caso DIR escolhido
									if (LadoEscolhido == 'D'){
										
										//Caso DIR NORMAL
										if (pecas[essapeca].Lado1 == Mesa[PosicaoNaMesa - 1].Lado2){
											Mesa[PosicaoNaMesa].Lado1 = pecas[essapeca].Lado1;
											Mesa[PosicaoNaMesa].Lado2 = pecas[essapeca].Lado2;
											pecas[essapeca].status = 'M';
											PosicaoNaMesa++;
											OK = 1;
										}
										
										//caso DIR INV
										else if (pecas[essapeca].Lado2 == Mesa[PosicaoNaMesa - 1].Lado2){
											Mesa[PosicaoNaMesa].Lado1 = pecas[essapeca].Lado2;
											Mesa[PosicaoNaMesa].Lado2 = pecas[essapeca].Lado1;
											pecas[essapeca].status = 'M';
											PosicaoNaMesa++;
											OK = 1;
										}	
									}
									
									// Caso ESQ escolhido
									else if (LadoEscolhido == 'E'){
										
										// Passa tds as pecas da mesa 1 posicao pra direita
										for (int j = PosicaoNaMesa; j >= 0; j--) {
											Mesa[j + 1] = Mesa[j];
										}
										
										//Caso ESQ NORMAL
										if (pecas[essapeca].Lado2 == Mesa[0].Lado1){
											Mesa[0].Lado1 = pecas[essapeca].Lado1;
											Mesa[0].Lado2 = pecas[essapeca].Lado2;
											pecas[essapeca].status = 'M';
											PosicaoNaMesa++;
											OK = 1;
										}
										
										//Caso ESQ INV
										else if (pecas[essapeca].Lado1 == Mesa[0].Lado1){
											Mesa[0].Lado1 = pecas[essapeca].Lado2;
											Mesa[0].Lado2 = pecas[essapeca].Lado1;
											pecas[essapeca].status = 'M';
											PosicaoNaMesa++;
											OK = 1;
										}
									} 
									
									// Caso nem DIR nem ESQ
									else{
										RepetirEscolherLado=1;
										mensagens(32);
									}
									
								}while (RepetirEscolherLado == 1);
							}
							
							// Verifica se eh valida na DIR
							else if ((pecas[essapeca].Lado1 == Mesa[PosicaoNaMesa - 1].Lado2) || (pecas[essapeca].Lado2 == Mesa[PosicaoNaMesa - 1].Lado2)){
								
								//Caso DIR NORMAL
								if (pecas[essapeca].Lado1 == Mesa[PosicaoNaMesa - 1].Lado2){
									Mesa[PosicaoNaMesa].Lado1 = pecas[essapeca].Lado1;
									Mesa[PosicaoNaMesa].Lado2 = pecas[essapeca].Lado2;
									pecas[essapeca].status = 'M';
									PosicaoNaMesa++;
									OK = 1;
								}
								
								//caso DIR INV
								else if (pecas[essapeca].Lado2 == Mesa[PosicaoNaMesa - 1].Lado2){
									Mesa[PosicaoNaMesa].Lado1 = pecas[essapeca].Lado2;
									Mesa[PosicaoNaMesa].Lado2 = pecas[essapeca].Lado1;
									pecas[essapeca].status = 'M';
									PosicaoNaMesa++;
									OK = 1;
								}
										
							}
							
							// Verifica se eh valida na ESQ
							else if ((pecas[essapeca].Lado1 == Mesa[0].Lado1) || (pecas[essapeca].Lado2 == Mesa[0].Lado1)){
										
								// Passa tds as pecas da mesa 1 pra direita
								for (int j = PosicaoNaMesa; j >= 0; j--) {
									Mesa[j + 1] = Mesa[j];
								}
										
								//Caso ESQ NORMAL
								if (pecas[essapeca].Lado2 == Mesa[0].Lado1){
									Mesa[0].Lado1 = pecas[essapeca].Lado1;
									Mesa[0].Lado2 = pecas[essapeca].Lado2;
									pecas[essapeca].status = 'M';
									PosicaoNaMesa++;
									OK = 1;
								}
										
								//Caso ESQ INV
								else if (pecas[essapeca].Lado1 == Mesa[0].Lado1){
									Mesa[0].Lado1 = pecas[essapeca].Lado2;
									Mesa[0].Lado2 = pecas[essapeca].Lado1;
									pecas[essapeca].status = 'M';
									PosicaoNaMesa++;
									OK = 1;
								}				
							}
							
							// Caso nenhum dos 3 acima
							else{
								RepetirJogarPeca = 1;
								mensagens(3);
								//printf("posicao na mesa: %d\n",PosicaoNaMesa);
								//printf("\npeca q eu escolhi: [%d|%d]\n",pecas[numeroX].Lado1,pecas[numeroX].Lado2);
							}
							
						} while(RepetirJogarPeca == 1);

							break;
						}
						case 'C':
						case 'c': {
							for (px = 0; px < 28; px++) {
								if (pecas[px].status == 'C') {
									pecas[px].status = '2';
									px = 28;

								}
							}
							mensagens(4);
							OK = 0;
							break;
						}
						case 'P':
						case 'p': {
							OK=1;
							break;
						}
						case 'S':
						case 's': {
							OK=1;
							Voltarpromenu=1;
							break;
						}
						default: {
							OK = 0;
							mensagens(5);
							break;
						}

					}
					mostraMesa = mostraMesa + 1;

				} while (OK == 0);

			}

			// CASO SEJA UM BOT
			else if (BotJogando == 1) {
				jogarBot();
			}

			// CASO NENHUM DOS 2
			else
				mensagens(6);
				
		}


		if (Voltarpromenu == 1) {
			VezSalvo = Vez;
			Vez = -1;
			system("cls");
		}

		// ---------- FIM DE JOGO ----------
		FimDeJogo();
		
		if (Vez != -1) {
			Turno = Turno + 1;
			Vez++;
		}

	} while (Vez != -1);	//vez = -1 : quando o jogo acabar, o vez sera trocado para -1.
	
}

//VOID do fim de jogo
	void FimDeJogo() {

		int SomaJog1 = 0;
		int SomaJog2 = 0;
		int NumeroDePecasJog1 = 0;
		int NumeroDePecasJog2 = 0;
		int LojaVazia = 0;
		int PecasPraJogar = 0;
		int Vitorioso;

		//Verifica se o jogo acaba ou nao
		for (int i = 0; i < 28; i++) {

			//Verifica se ainda ha pecas na loja
			if (pecas[i].status == 'C') {
				LojaVazia = 1;
			}

			//Verifica se os jogadores ainda tem pecas que podem ser jogadas
			else if ((pecas[i].status == '1') || (pecas[i].status == '2')) {

				//Verifica caso seja jogada na Direita
				if ((pecas[i].Lado1 == Mesa[PosicaoNaMesa - 1].Lado2) || (pecas[i].Lado2 == Mesa[PosicaoNaMesa - 1].Lado2)) {
					PecasPraJogar = 1;
				}

				//Verifica caso seja jogada na Esquerda
				else if ((pecas[i].Lado1 == Mesa[0].Lado2) || (pecas[i].Lado2 == Mesa[0].Lado2)) {
					PecasPraJogar = 1;
				}
			}
		}

		//Finaliza o jogo
		if ((LojaVazia == 0) && (PecasPraJogar == 0)) {

			mensagens(7);
			//Soma todas as pecas || Conta todas as pecas
			for (int i = 0; i < 28; i++) {
				if (pecas[i].status == '1') {
					NumeroDePecasJog1++;
					SomaJog1 = SomaJog1 + pecas[i].Lado1 + pecas[i].Lado2;
				} else if (pecas[i].status == '2') {
					NumeroDePecasJog2++;
					SomaJog2 = SomaJog2 + pecas[i].Lado1 + pecas[i].Lado2;
				}
			}

			//Identifica quem foi o vencedor
			if (NumeroDePecasJog1 < NumeroDePecasJog2)
				Vitorioso = 1;
			else if (NumeroDePecasJog2 < NumeroDePecasJog1)
				Vitorioso = 2;
			else if (SomaJog1 < SomaJog2)
				Vitorioso = 1;
			else if (SomaJog2 < SomaJog1)
				Vitorioso = 2;
			else
				mensagens(8);
				
			//jogador vencedor
			mensagens(9);
			
			//Fecha todos os Do's
			Vez = -1;
		}

	}

	void SalvarJogo() {
		mensagens(10);
		FILE* fp;

		if ((fp = fopen("PecasJogadores", "w")) == NULL) {
			mensagens(11);
			exit(0);
		}

		for (int i = 0; i < 28; i++) {
			if (fwrite(&pecas[i], sizeof(struct pc), 1, fp) != 1) {
				mensagens(12);
				break;
			}
		}
		fclose(fp);

		if ((fp = fopen("PosicaoNaMesa", "w")) == NULL) {
			mensagens(13);
			exit(0);
		}
		if (fwrite(&PosicaoNaMesa, sizeof(int), 1, fp) != 1) {
			mensagens(14);
		}
		fclose(fp);

		if ((fp = fopen("Mesa", "w")) == NULL) {
			mensagens(15);
			exit(0);
		}

		for (int i = 0; i < PosicaoNaMesa; i++) {
			if (fwrite(&Mesa[i], sizeof(struct pc), 1, fp) != 1) {
				mensagens(16);
				break;
			}
		}
		fclose(fp);

		if ((fp = fopen("VezSalvo", "w")) == NULL) {
			mensagens(17);
			exit(0);
		}
		if (fwrite(&VezSalvo, sizeof(int), 1, fp) != 1) {
			mensagens(18);
		}
		fclose(fp);

		mensagens(19);
	}

	void RecuperaJogo() {
		FILE* fp;
		if ((fp = fopen("PecasJogadores", "r")) == NULL) {
			mensagens(20);
			exit(0);
		}

		for (int i = 0; i < 28; i++) {
			if (fread(&pecas[i], sizeof(struct pc), 1, fp) != 1) {
				mensagens(21);
				break;
			}
		}
		fclose(fp);

		if ((fp = fopen("PosicaoNaMesa", "r")) == NULL) {
			mensagens(22);
			exit(0);
		}
		if (fread(&PosicaoNaMesa, sizeof(int), 1, fp) != 1) {
			mensagens(23);
		}
		fclose(fp);

		if ((fp = fopen("Mesa", "r")) == NULL) {
			mensagens(24);
			exit(0);
		}

		for (int i = 0; i < PosicaoNaMesa; i++) {
			if (fread(&Mesa[i], sizeof(struct pc), 1, fp) != 1) {
				mensagens(25);
				break;
			}
		}
		fclose(fp);

		if ((fp = fopen("VezSalvo", "r")) == NULL) {
			mensagens(26);
			exit(0);
		}
		if (fread(&VezSalvo, sizeof(int), 1, fp) != 1) {
			mensagens(27);
		}
		fclose(fp);

	}
//S2

	void jogarBot() {

		int Comprar=1;
		int OK=0;
		int LojaVazia=1;

		do {
			for (int px = 0; px < 28; px++) {
				if (pecas[px].status == '2') {

					//Verifica se eh valida NORMAL na DIREITA
					if (pecas[px].Lado1 == Mesa[PosicaoNaMesa - 1].Lado2) {
						Comprar = 0;
						Mesa[PosicaoNaMesa].Lado1 = pecas[px].Lado1;
						Mesa[PosicaoNaMesa].Lado2 = pecas[px].Lado2;
						pecas[px].status = 'M';
						PosicaoNaMesa++;
						OK = 1;
					}

					//Verifica se eh valida INVERTIDA na DIREITA
					else if (pecas[px].Lado2 == Mesa[PosicaoNaMesa - 1].Lado2) {
						Comprar = 0;
						Mesa[PosicaoNaMesa].Lado1 = pecas[px].Lado2;
						Mesa[PosicaoNaMesa].Lado2 = pecas[px].Lado1;
						pecas[px].status = 'M';
						PosicaoNaMesa++;
						OK = 1;
					}

					// Verifica se eh valida INVERTIDA na ESQUERDA
					else if (pecas[px].Lado1 == Mesa[0].Lado1) {
						Comprar = 0;
						// Passa todas as pecas 1 posicao pra direita
						for (int j = PosicaoNaMesa; j >= 0; j--) {
							Mesa[j + 1] = Mesa[j];
						}
						Mesa[0].Lado1 = pecas[px].Lado2;
						Mesa[0].Lado2 = pecas[px].Lado1;
						pecas[px].status = 'M';
						PosicaoNaMesa++;
						OK = 1;
					}

					// Verifica se eh valida NORMALMENTE na ESQUERDA
					else if (pecas[px].Lado2 == Mesa[0].Lado1) {
						Comprar = 0;
						for (int j = PosicaoNaMesa; j >= 0; j--) {
							Mesa[j + 1] = Mesa[j];
						}
						Mesa[0].Lado1 = pecas[px].Lado1;
						Mesa[0].Lado2 = pecas[px].Lado2;
						pecas[px].status = 'M';
						PosicaoNaMesa++;
						OK = 1;
					}
				}

				//Caso um dos 4 acima for ativado
				if (Comprar == 0) {
					break;
				}

			}

			//Caso nenhum dos 4 acima for ativado
			if (Comprar == 1) {
				for (int i = 0; i < 28; i++) {
					//Compra peca
					if (pecas[i].status == 'C') {
						pecas[i].status = '2';
						LojaVazia = 0;
						break;
					}
				}
				//Caso loja esteja vazia, passa a vez
				if (LojaVazia == 1) {
					break;
				}
			}

		} while (OK == 0);

	}



void fclear()
{
	char carac;
    while( (carac = fgetc(stdin)) != EOF && carac != '\n') {}
}
